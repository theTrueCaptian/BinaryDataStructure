
Here is how to run:
java -jar "F:\BinaryDataStructure\DisplayBinary\dist\DisplayBinary.jar"

******************************************************************************
Note: Please replace F with your directory to where this jar file is copied.
******************************************************************************